"""Draw the synthetic experiment figures from the benchmark CSV outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

D = Path(__file__).resolve().parent
INK, BLUE, TEAL, RUST, GREY = "#162B3A", "#176887", "#147A6D", "#A65330", "#647883"
PALE, WHITE = "#E2EBEC", "#FFFFFF"
mpl.rcParams.update({"font.family":"Liberation Sans","font.size":8.5,"axes.labelsize":8.7,
     "axes.spines.top":False,"axes.spines.right":False,"axes.edgecolor":GREY,"axes.linewidth":.7,
     "xtick.major.size":3,"ytick.major.size":3,"xtick.major.width":.65,"ytick.major.width":.65,
     "xtick.color":INK,"ytick.color":INK,"axes.labelcolor":INK,"text.color":INK,
     "svg.fonttype":"path","mathtext.fontset":"stixsans"})
def header(ax,letter,title,y=1.07):
    ax.text(-.055,y,letter,transform=ax.transAxes,fontsize=11.5,color=BLUE,fontweight="bold",va="baseline")
    ax.annotate(title,xy=(-.055,y),xycoords=ax.transAxes,xytext=(16,0),textcoords="offset points",
                fontsize=9.2,fontweight="bold",va="baseline")
def grid(ax,axis="y"):
    ax.grid(axis=axis,color=PALE,lw=.6)
    ax.set_axisbelow(True)
def save(fig,n):
    for suffix in ("svg","png"):
        fig.savefig(D/f"figure_{n}.{suffix}",dpi=680,facecolor="white")
    plt.close(fig)
def legend(handles,fig,y,cols):
    fig.legend(handles=handles,loc="center",bbox_to_anchor=(.515,y),ncols=cols,
               frameon=False,handletextpad=.55,columnspacing=1.25,fontsize=8.0)
def key(c,pattern,m,label):
    return Line2D([],[],color=c,linestyle=pattern,marker=m,markersize=4,linewidth=1.45,
                  markerfacecolor="white",markeredgewidth=1.,label=label)

a=pd.read_csv(D/"input_dependence.csv")
factorial=a[a.experiment=="copula"]
permuted=a[a.stress_mapping=="permuted"].iloc[0]
coupled=a[(a.experiment=="stress_mapping") & (a.stress_mapping=="coupled")].iloc[0]
fig=plt.figure(figsize=(6.75,3.92))
specs=[(.093,.515,.365,.355),(.584,.515,.365,.355)]
for i,(rect,metric,title,ylim) in enumerate(zip(specs,("either_pct","both_pct"),
        ("Either criterion exceeded","Both criteria exceeded"),((53,64),(26,46)))):
    ax=fig.add_axes(rect)
    header(ax,"ab"[i],title)
    for j,(s,c,m,ls) in enumerate([(.07,GREY,"s","--"),(.12,BLUE,"o","-"),(.16,TEAL,"^","-.")]):
        rows=factorial[np.isclose(factorial.sigma_i,s)].sort_values("latent_rho")
        ax.plot(rows.latent_rho,rows[metric],color=c,marker=m,linestyle=ls,lw=1.4,ms=4.4,
                markerfacecolor="white",markeredgewidth=1.)
    ax.set(xlim=(-.65,.65),ylim=ylim,ylabel="Exceedance (%)")
    ax.set_xticks([-.55,0,.55],["−0.55","0","+0.55"])
    ax.set_xlabel(r"Latent stress–stiffness correlation, $\rho$")
    grid(ax)
legend([key(GREY,"--","s",r"$s_I=0.07$"),key(BLUE,"-","o",r"$s_I=0.12$"),
        key(TEAL,"-.","^",r"$s_I=0.16$")],fig,.378,3)
ax=fig.add_axes([.24,.150,.71,.151])
header(ax,"c","Effect of permuting out-of-plane stress",y=1.14)
ax.set(xlim=(-1.6,8.5),ylim=(-.56,1.54),xlabel="Change or disagreement (percentage points)")
ax.set_yticks([1,0],["Closure","Bolt force"])
ax.axvline(0,color=GREY,lw=.75)
grid(ax,"x")
for y,field,color in [(1,"closure",BLUE),(0,"bolt",TEAL)]:
    discord=permuted[f"{field}_discord_pp"]
    difference=permuted[f"{field}_pct"]-coupled[f"{field}_pct"]
    ax.barh(y,discord,height=.38,color=color,alpha=.24,zorder=3)
    ax.plot(difference,y,"D",color=color,mec="white",mew=.55,ms=6,zorder=5)
    ax.text(discord+.16,y,f"{discord:.2f}",color=color,va="center",fontsize=8.0)
fig.text(.95,.023,"Bar: paired disagreement     Diamond: signed probability change",
         ha="right",va="center",fontsize=7.5,color=GREY)
save(fig,5)

data=pd.read_csv(D/"surrogate_comparison.csv")
fig=plt.figure(figsize=(6.75,4.35))
metrics=[("near_discord_pct","Closure near threshold","Wrong classification (%)"),("near_discord_pct","Bolt force near threshold","Wrong classification (%)"),
         ("rmse","Closure over full test set","RMSE (mm)"),("rmse","Bolt force over full test set","RMSE (kN)")]
positions=[(.103,.573,.346,.288),(.594,.573,.346,.288),(.103,.178,.346,.288),(.594,.178,.346,.288)]
for i,((field,title,ylabel),rect) in enumerate(zip(metrics,positions)):
    ax=fig.add_axes(rect)
    header(ax,"abcd"[i],title)
    criterion="closure" if i%2==0 else "bolt"
    for method,color,marker,ls in [("passive",GREY,"s","--"),("threshold",TEAL,"o","-")]:
        cohort=data[(data.criterion==criterion)&(data.method==method)]
        values=cohort.groupby("calibration_cases")[field].quantile([.25,.5,.75]).unstack()
        ax.fill_between(values.index,values[.25],values[.75],color=color,alpha=.15,lw=0)
        ax.plot(values.index,values[.5],color=color,marker=marker,linestyle=ls,ms=4.8,mfc="white",mew=1,lw=1.55)
    ax.set(xlim=(20,100),ylabel=ylabel)
    ax.set_xticks([24,48,72,96])
    if i>=2:
        ax.set_xlabel("Calibration cases")
    grid(ax)
legend([key(GREY,"--","s","Random enrichment"),key(TEAL,"-","o","Threshold-guided enrichment")],
       fig,.038,2)
save(fig,6)

data=pd.read_csv(D/"interruptions.csv")
fig=plt.figure(figsize=(6.75,4.51))
for i,(criterion,x) in enumerate([("closure",.105),("bolt",.596)]):
    ax=fig.add_axes([x,.584,.347,.277])
    header(ax,"ab"[i],("Closure" if i==0 else "Bolt force")+" estimate bias")
    ax.axhline(0,color=GREY,lw=.7)
    for mechanism,protocol,col,ls,m in [
            ("random","single_pass",GREY,":","s"),("stress_stiffness","single_pass",RUST,"-","o"),
            ("stress_stiffness","retry",TEAL,"--","^")]:
        rows=data[(data.criterion==criterion)&(data.mechanism==mechanism)&(data.protocol==protocol)].sort_values("injected_rate")
        ax.plot(100*rows.injected_rate,rows.resolved_only_pct-rows.true_pct,color=col,
                lw=1.4,linestyle=ls,marker=m,mfc="white",mew=1,ms=4.1)
    ax.set(xlim=(1.4,16.1),ylim=(-10,.75),ylabel="Bias (percentage points)",xlabel="Injected interruptions (%)")
    ax.set_xticks([2.5,5,10,15])
    grid(ax)
for i,(criterion,x) in enumerate([("closure",.22),("bolt",.642)]):
    ax=fig.add_axes([x,.139,.325,.235])
    header(ax,"cd"[i],("Closure" if i==0 else "Bolt force")+" at 10% interruption",y=1.10)
    section=data[(data.criterion==criterion)&np.isclose(data.injected_rate,.10)]
    configurations=[
       ("random","single_pass",GREY,"Random"),
       ("stress_stiffness","single_pass",RUST,"Stress-related"),
       ("stress_stiffness","retry",TEAL,"With retry"),
    ]
    ax.axvline(section.true_pct.iloc[0],c=BLUE,lw=1,ls=(0,(2,2)),zorder=1)
    for y,(m,p,c,name) in zip([2,1,0],configurations):
        row=section[(section.mechanism==m)&(section.protocol==p)].iloc[0]
        ax.hlines(y,row.lower_pct,row.upper_pct,color=c,lw=2,zorder=3)
        ax.plot([row.lower_pct,row.upper_pct],[y,y],"|",color=c,mew=1.,ms=7)
        ax.plot(row.resolved_only_pct,y,"D",mfc=WHITE,mec=c,mew=1.15,ms=4.7,zorder=4)
    ax.set(xlim=(35.5,55.5),ylim=(-.6,2.6),xlabel="Exceedance (%)")
    ax.set_xticks([36,40,45,50,55])
    ax.set_yticks([2,1,0],["Random","Stress-related","With retry"] if i==0 else ["","",""])
    ax.tick_params(axis="y",length=0)
    ax.spines["left"].set_visible(False)
    grid(ax,"x")
legend([key(GREY,":","s","Random"),key(RUST,"-","o","Stress-related"),key(TEAL,"--","^","Stress-related with retry")],
       fig,.453,3)
fig.text(.58,.025,"Interval: unresolved-case bounds     Diamond: resolved only     Blue line: benchmark",
         ha="center",va="center",fontsize=7.4,color=GREY)
save(fig,7)
