Numerical benchmark for An AI Agent for Probabilistic Geotechnical Analysis

The benchmark uses closed-form synthetic response functions. It reproduces the
three methodological experiments and the corresponding Figures 5–7 in the
chapter. The historical tailrace values discussed in Section 6.3 come from the
16YGPC manuscript and are outside the benchmark code.

Tested with Python 3.12, NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3 and
Matplotlib 3.10.8. The plotting script uses Liberation Sans if installed.

To reproduce the CSV files and figures from scratch, run:

    python -m pip install -r requirements.txt
    python benchmark.py
    python plot_results.py

Code, outputs and the plotting script use paths relative to this directory.
For consistent numerical comparisons, use the dependency versions listed.
Figure styling uses a local font and can vary slightly across installations.

Output files
- input_dependence.csv: nine copula scenarios and two stress mapping scenarios.
- surrogate_comparison.csv: replicate-level metrics for both strategies at
  four calibration budgets and for two response criteria.
- interruptions.csv: bias inputs and unresolved-case bounds for four injected
  rates, two missingness mechanisms, two protocols and two response criteria.
- figure_5.svg, figure_6.svg and figure_7.svg: vector results figures.

In the CSV headers, pct indicates a percentage and pp indicates percentage
points. Bias is predicted minus complete-sample benchmark probability. The
false-positive and false-negative rates use the complete test-set denominator.
Near-threshold disagreement uses the number of benchmark cases within the
criterion-specific band. rmse is in mm for closure and kN for bolt force.
The benchmark output rows retain full calculation precision.
