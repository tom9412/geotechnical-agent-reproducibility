"""Reproduce the synthetic benchmarks in the book chapter.

Requires Python 3, NumPy and SciPy. Run this file from its directory.
The closed-form response generator and injected interruptions have no RS2 dependency.
"""
from pathlib import Path
import csv
import numpy as np
from scipy.special import ndtr, ndtri
from scipy.stats import qmc

RESULT = Path(__file__).resolve().parent
N = 120_000
TEST_SEED = 20261116
REPEATS = 32
BUDGETS = (24, 48, 72, 96)
THRESHOLD = np.array([30., 358.])
NEAR = np.array([2., 15.])
RESPONSES = ("closure", "bolt")

def truncated(z, centre, standard_deviation, lower, upper):
    low = ndtr((lower-centre)/standard_deviation)
    high = ndtr((upper-centre)/standard_deviation)
    return centre + standard_deviation * ndtri(low + ndtr(z) * (high-low))

def sample(z, sigma_i=.12, rho=0.):
    inheritance = truncated(z[:,0], .325, sigma_i, .06, .66)
    rock_stiffness = rho*z[:,0] + np.sqrt(1-rho*rho)*z[:,1]
    log_modulus = truncated(rock_stiffness, 0., .40, np.log(.40), np.log(2.5))
    angle = truncated(z[:,2], 0., 16., -40., 40.)
    return np.column_stack((inheritance, log_modulus, angle))

def response(inputs, out_of_plane_inheritance=None):
    inheritance, log_modulus, angle = inputs.T
    if out_of_plane_inheritance is None:
        out_of_plane_inheritance = inheritance
    x = (inheritance-.325)/.12
    z = (out_of_plane_inheritance-.325)/.12
    ell = log_modulus/.40
    r = inheritance/.325
    s = np.sin(np.deg2rad(2*angle))
    closure = (29.5 + 3.9*x + .9*z - 4.3*ell + .55*x*x - .80*x*ell
               + 1.1*r*s*s + 2.8*np.maximum(x-.25,0.)**2)
    bolt = (350. + 25.*x + 7.*z - 7.*ell + r*(22.*s+30.*s*s)
            + 20.*np.maximum(x+.60*r*s-.40,0.)**2)
    return np.column_stack((closure, bolt))

def event(values):
    return values > THRESHOLD

def write(name, rows):
    file = RESULT/name
    with file.open('w',newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def design(inputs):
    a,b,c = (inputs-np.array([.325,0.,0.])).T/np.array([.12,.40,16.])[:,None]
    return np.column_stack((np.ones_like(a),a,b,c,a*a,b*b,c*c,a*b,a*c,b*c))

def fit(inputs):
    return np.linalg.lstsq(design(inputs), response(inputs), rcond=None)[0]

def evaluate(test_design, truth, coefficients):
    fitted = test_design @ coefficients
    oracle, estimate = event(truth), event(fitted)
    wrong = (oracle != estimate)
    near = np.abs(truth-THRESHOLD) <= NEAR
    fn = oracle & ~estimate
    fp = estimate & ~oracle
    return {
        "bias_pp": 100.*(estimate.mean(axis=0)-oracle.mean(axis=0)),
        "discord_pp": 100.*wrong.mean(axis=0),
        "near_discord_pct": 100.*(wrong & near).sum(axis=0)/near.sum(axis=0),
        "false_negative_pp": 100.*fn.mean(axis=0),
        "false_positive_pp": 100.*fp.mean(axis=0),
        "rmse": np.sqrt(np.mean((fitted-truth)**2, axis=0)),
    }

def choose_near(pool_features, current, available):
    """Choose a shared group of six points per response, without oracle access."""
    predicted = pool_features @ fit(current)
    scaled_margins = np.abs(predicted-THRESHOLD)/NEAR
    ranking = np.argsort(scaled_margins, axis=0, kind="stable")
    points = []
    for position in range(12):
        column = position%2
        for candidate in ranking[:,column]:
            if available[candidate]:
                available[candidate] = False
                points.append(candidate)
                break
    return points

def study_inputs(latent, base_inputs, base_values):
    rows=[]
    base_event = event(base_values)
    for sigma_i in (.07,.12,.16):
        for rho in (-.55,0.,.55):
            inputs = sample(latent, sigma_i, rho)
            values = event(response(inputs))
            rows.append(dict(experiment="copula", sigma_i=sigma_i, latent_rho=rho,
                             stress_mapping="coupled",
                             realised_rho=np.corrcoef(inputs[:,:2].T)[0,1],
                             closure_pct=100.*values[:,0].mean(), bolt_pct=100.*values[:,1].mean(),
                             either_pct=100.*values.any(axis=1).mean(),
                             both_pct=100.*values.all(axis=1).mean(),
                             closure_discord_pp="",bolt_discord_pp=""))
    # Permuting the IDs preserves the out-of-plane stress marginal exactly.
    shuffle=np.random.default_rng(TEST_SEED+1).permutation(N)
    broken = event(response(base_inputs,base_inputs[shuffle,0]))
    for text, values in [("coupled",base_event),("permuted",broken)]:
        rows.append(dict(experiment="stress_mapping", sigma_i=.12,latent_rho=0.,
                         stress_mapping=text,realised_rho=np.corrcoef(base_inputs[:,:2].T)[0,1],
                         closure_pct=100.*values[:,0].mean(),bolt_pct=100.*values[:,1].mean(),
                         either_pct=100.*values.any(axis=1).mean(),both_pct=100.*values.all(axis=1).mean(),
                         closure_discord_pp=100.*(values[:,0]!=base_event[:,0]).mean(),
                         bolt_discord_pp=100.*(values[:,1]!=base_event[:,1]).mean()))
    return rows

def study_surrogates(test, truth):
    rows=[]
    test_features=design(test)
    low=np.array([.06,np.log(.4),-40.])
    high=np.array([.66,np.log(2.5),40.])
    for replicate in range(REPEATS):
        seed=3100+replicate
        start=qmc.scale(qmc.LatinHypercube(3,seed=seed).random(24),low,high)
        rng=np.random.default_rng(4100+replicate)
        pool=sample(rng.standard_normal((4096,3)))
        features=design(pool)
        for method in ("passive","threshold"):
            current=start.copy()
            available=np.ones(len(pool),dtype=bool)
            for count in range(24,97,12):
                if count in BUDGETS:
                    metrics=evaluate(test_features,truth,fit(current))
                    for j,criterion in enumerate(RESPONSES):
                        rows.append(dict(method=method,replicate=replicate,calibration_cases=count,criterion=criterion,
                                         **{key:float(value[j]) for key,value in metrics.items()}))
                if count==96:
                    break
                if method=="threshold":
                    take=choose_near(features,current,available)
                else:
                    take=rng.choice(np.flatnonzero(available),12,replace=False)
                    available[take]=False
                current=np.vstack((current,pool[take]))
    return rows

def study_interruptions(inputs, truth):
    # Intervention labels are injected after exact evaluations to keep a reference.
    severity=(inputs[:,0]-.325)/.12 - .8*inputs[:,1]/.40
    ranked=np.argsort(severity,kind="stable")
    permutation=np.random.default_rng(7110).permutation(len(inputs))
    recovered=np.random.default_rng(7111).random(len(inputs))<.55
    outcomes=event(truth)
    rows=[]
    for rate in (.025,.05,.10,.15):
        m=int(round(len(inputs)*rate))
        for mechanism,ranking in [("random",permutation),("stress_stiffness",ranked[::-1])]:
            omitted=np.zeros(len(inputs),dtype=bool)
            omitted[ranking[:m]]=True
            for protocol,unknown in [("single_pass",omitted),("retry",omitted & ~recovered)]:
                for j,criterion in enumerate(RESPONSES):
                    k=(outcomes[:,j] & ~unknown).sum()
                    remaining=int(unknown.sum())
                    rows.append(dict(criterion=criterion,injected_rate=rate,mechanism=mechanism,
                                     protocol=protocol,unresolved=remaining,
                                     true_pct=100.*outcomes[:,j].mean(),
                                     resolved_only_pct=100.*k/(len(inputs)-remaining),
                                     lower_pct=100.*k/len(inputs),upper_pct=100.*(k+remaining)/len(inputs),
                                     unresolved_exceed_pct=100.*(outcomes[:,j]&unknown).sum()/remaining))
    return rows

def run():
    latent=np.random.default_rng(TEST_SEED).standard_normal((N,3))
    test=sample(latent)
    truth=response(test)
    assert np.allclose(response(np.array([[.325,0.,0.]])),[[29.5,350.]])
    assert np.allclose(response(np.array([[0.,0.,-40.],[0.,0.,40.]]))[0],
                       response(np.array([[0.,0.,-40.],[0.,0.,40.]]))[1])
    assert np.all(truth>0)
    write("input_dependence.csv",study_inputs(latent,test,truth))
    write("surrogate_comparison.csv",study_surrogates(test,truth))
    missing=study_interruptions(test,truth)
    assert all(r["lower_pct"]<=r["true_pct"]<=r["upper_pct"] for r in missing)
    write("interruptions.csv",missing)
    print("Benchmark exceedance percentages:", 100.*event(truth).mean(axis=0))
    print("Samples in the near-threshold bands:", (np.abs(truth-THRESHOLD)<=NEAR).sum(axis=0))

if __name__=="__main__":
    run()
