"""Replay the observed tool calls and test the deterministic boundary."""
from copy import deepcopy
from pathlib import Path
import csv
import json

from agent_tools import APPROVED, MODEL, ORIENTATION, PLAN, SCHEMAS, SPEC, call, new_state

D = Path(__file__).resolve().parent
RECEIPT = {"spec_id": APPROVED}


def run(state, tool, args):
    return call(state, tool, args, origin="scripted_evaluation")


def approved_state(pilot=False, batch=False):
    state = new_state()
    run(state, "ask_engineer", {"field":"orientation_id","question":"Confirm the angle convention."})
    assert run(state, "prepare_spec", SPEC)["status"]=="APPROVED"
    if pilot or batch:
        assert run(state,"run_pilot",RECEIPT)["status"]=="PASS"
    if batch:
        assert run(state,"run_batch",RECEIPT)["status"]=="BATCH_COMPLETE"
    return state


def evaluate_guards():
    ready=approved_state()
    batch=approved_state(batch=True)
    alternative=deepcopy(ready)
    alternate_id=run(alternative,"prepare_spec",SPEC | {"reference_stage_id":"INITIAL"})["spec_id"]
    checks=[
        ("wrong_argument_type",ready,"prepare_spec",SPEC | {"orientation_id":45},"SCHEMA_ERROR"),
        ("unexpected_argument",ready,"prepare_spec",SPEC | {"angle_override":90},"SCHEMA_ERROR"),
        ("missing_orientation",new_state(),"prepare_spec",SPEC | {"orientation_id":None},"NEED_INPUT"),
        ("guessed_existing_convention",new_state(),"prepare_spec",SPEC,"ORIENTATION_UNVERIFIED"),
        ("clockwise_convention",ready,"prepare_spec",SPEC | {"orientation_id":"CLOCKWISE"},"UNSUPPORTED_ORIENTATION"),
        ("invented_stage",ready,"prepare_spec",SPEC | {"result_stage_id":"EXCAVATION_04"},"UNKNOWN_STAGE"),
        ("reversed_stages",ready,"prepare_spec",SPEC | {"reference_stage_id":"END_EXCAVATION","result_stage_id":"SUPPORT_INSTALLED"},"STAGE_ORDER_INVALID"),
        ("valid_but_unapproved_stage_pair",alternative,"run_pilot",{"spec_id":alternate_id},"APPROVAL_REQUIRED"),
        ("batch_without_pilot",ready,"run_batch",RECEIPT,"PILOT_REQUIRED"),
        ("report_before_disposition",batch,"report",RECEIPT,"ACTIONS_PENDING"),
        ("retry_nonconvergence",batch,"act_on_status",RECEIPT | {"sample_id":"S042","action":"retry_same_inputs"},"RETRY_BLOCKED"),
        ("retry_readback_mismatch",batch,"act_on_status",RECEIPT | {"sample_id":"S052","action":"retry_same_inputs"},"RETRY_BLOCKED"),
        ("invented_sample",batch,"act_on_status",RECEIPT | {"sample_id":"S099","action":"flag_for_review"},"UNKNOWN_SAMPLE"),
        ("duplicate_batch",batch,"run_batch",RECEIPT,"BATCH_EXISTS"),
    ]
    rows=[]
    for name,start,tool,arguments,expected in checks:
        state=deepcopy(start)
        counts_before=deepcopy(state["batches"])
        outcome=run(state,tool,arguments)
        assert outcome["status"]==expected and state["batches"]==counts_before
        rows.append({"case":name,"tool":tool,"expected":expected,"observed":outcome["status"],
                     "attempts_or_classifications_changed":False})
    return rows


def compare_to_fixed_workflow(observed_report):
    # This comparator receives a complete, fixture-approved structured specification.
    state=approved_state(batch=True)
    for sample_id,case in state["batches"][APPROVED].items():
        status=case["attempts"][-1]["status"]
        if status=="OK":
            continue
        action="retry_same_inputs" if status=="TRANSIENT_IO" else "flag_for_review"
        run(state,"act_on_status",RECEIPT | {"sample_id":sample_id,"action":action})
    fixed=run(state,"report",RECEIPT)
    assert fixed==observed_report
    return fixed


def main():
    observed=json.loads((D/"reference_trace.json").read_text())
    dispatch_log=observed["calls"]
    state=new_state()
    for row in dispatch_log:
        assert run(state,row["tool"],row["arguments"])==row["result"],row
    expected_report=dispatch_log[-1]["result"]
    assert expected_report["planned"]==64 and expected_report["resolved"]==62
    assert expected_report["total_attempts"]==65 and len(dispatch_log)==10
    cases=state["batches"][APPROVED]
    assert [x["input_id"] for x in cases["S017"]["attempts"]].count(cases["S017"]["input_id"])==2
    assert all(cases[key]["review"] and len(cases[key]["attempts"])==1 for key in ["S042","S052"])
    guards=evaluate_guards()
    baseline=compare_to_fixed_workflow(expected_report)
    with (D/"guard_results.csv").open("w",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(guards[0]))
        writer.writeheader()
        writer.writerows(guards)
    (D/"reference_tool_schema.json").write_text(json.dumps(SCHEMAS,indent=2))
    summary={"live_tool_invocations":len(dispatch_log),"guard_cases":len(guards),
             "guard_cases_passed":len(guards),"fixed_report_equals_observed":baseline==expected_report,
             "prototype_report":expected_report,"fixed_workflow_report":baseline}
    (D/"reference_evaluation.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    main()
