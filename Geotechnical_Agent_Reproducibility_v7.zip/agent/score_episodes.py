"""Replay tool traces, score the four prompt categories and verify benchmarks."""
from copy import deepcopy
import csv
import json
from pathlib import Path

import numpy as np
from agent_tools import APPROVED, RESPONSE_LIMITS, SPEC, response
from controller_eval import CASES, SCHEMAS, call, new_episode, CHECKED_FIELDS
from evaluate_reference import compare_to_fixed_workflow, evaluate_guards

D=Path(__file__).resolve().parent
ERRORS={"SCHEMA_ERROR","UNKNOWN_MODEL","UNKNOWN_PLAN","UNKNOWN_STAGE","STAGE_ORDER_INVALID",
        "UNSUPPORTED_ORIENTATION","ORIENTATION_UNVERIFIED","EVIDENCE_REQUIRED",
        "STAGE_ROLE_MISMATCH","APPROVAL_REQUIRED","UNKNOWN_SPEC","PILOT_REQUIRED",
        "BATCH_EXISTS","NO_BATCH","UNKNOWN_SAMPLE","ALREADY_HANDLED","RETRY_BLOCKED",
        "ACTIONS_PENDING","NO_OUTSTANDING_FIELD"}


def write_csv(name, rows):
    with (D/name).open("w",newline="") as fh:
        writer=csv.DictWriter(fh,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def score():
    reference=json.loads((D/"reference_trace.json").read_text())
    ref_report=reference["calls"][-1]["result"]
    fixed=compare_to_fixed_workflow(ref_report)
    original=reference["batches"][APPROVED]
    full_values=response(np.array([entry["input"] for entry in original.values()]))
    oracle=dict(zip(RESPONSE_LIMITS,(full_values>np.array(list(RESPONSE_LIMITS.values()))).sum(axis=0).astype(int).tolist()))
    assert all(k==28 for k in oracle.values())
    assert len(evaluate_guards())==14
    rows=[]
    for key,value in CASES.items():
        observed=json.loads((D/"episodes"/f"{key}.json").read_text())
        state=new_episode(key)
        calls=observed["calls"]
        approved=[]
        reports=[]
        dispositions=[]
        for event in calls:
            assert call(state,event["tool"],event["arguments"])==event["result"]
            mode=event["result"]["status"]
            if mode=="APPROVED": approved.append(event)
            if mode=="REPORT_READY": reports.append(event)
            if mode in ("RETRIED","FLAGGED_FOR_REVIEW"):
                dispositions.append((event["arguments"]["sample_id"],event["arguments"]["action"]))
        assert state==observed
        passed=(len(approved)==1 and approved[0]["arguments"]==SPEC
                and state["specs"].get(APPROVED)==SPEC)
        confirm=[event for event in calls if event["result"]["status"]=="FIXTURE_REPLY"]
        clarified={field for event in confirm for field in event["result"]["resolved"]}
        assert clarified==set(CHECKED_FIELDS.get(key,()))
        actions=(set(dispositions)=={("S017","retry_same_inputs"),
                 ("S042","flag_for_review"),("S052","flag_for_review")} and len(dispositions)==3)
        assert actions
        blocked=[event["result"]["status"] for event in calls if event["result"]["status"] in ERRORS]
        need=sum(event["result"]["status"]=="NEED_INPUT" for event in calls)
        rows.append({"episode":key,"category":value["category"],"correct_spec":int(passed),
                     "clarification_turns":len(confirm),"needs_input_statuses":need,
                     "blocked_calls":len(blocked),"blocked_statuses":";".join(blocked),
                     "reportMatchesFixed":int(len(reports)==1 and reports[0]["result"]==fixed),
                     "appropriate_dispositions":int(actions),"tool_calls":len(calls)})
    fields=("correct_spec","clarification_turns","needs_input_statuses","blocked_calls",
            "reportMatchesFixed","appropriate_dispositions","tool_calls")
    groups=list(dict.fromkeys(row["category"] for row in rows))
    def aggregate(label, cases):
        return {"category":label,"episodes":len(cases),
                **{k:sum(row[k] for row in cases) for k in fields}}
    summary=[aggregate(label,[row for row in rows if row["category"]==label]) for label in groups]
    summary.append(aggregate("total",rows))
    write_csv("episode_scores.csv",rows)
    write_csv("group_scores.csv",summary)
    (D/"tool_schema.json").write_text(json.dumps(SCHEMAS,indent=2)+"\n")
    (D/"fixed_report.json").write_text(json.dumps({"fixed_workflow":fixed,
       "fully_evaluated_synthetic_reference":{"N":len(original),"exceedance_counts":oracle}},indent=2)+"\n")
    for row in summary: print(json.dumps(row))


if __name__=="__main__":
    score()
