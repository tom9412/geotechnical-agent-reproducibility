"""Run one action per independent dispatcher state for the prompt-coverage study.

The controller must choose the tools. This module only validates and executes calls.
"""
from argparse import ArgumentParser
import csv
from copy import deepcopy
import json
from pathlib import Path
import sys

from agent_tools import (
    MODEL, ORIENTATION, REFERENCE, RESULT, SCHEMAS, SPEC, STAGES,
    dispatch, new_state, object_schema, result,
)
from jsonschema import Draft202012Validator


ROOT=Path(__file__).resolve().parent
CASES={entry["episode"]:entry for entry in csv.DictReader((ROOT/"prompts.tsv").open(),delimiter="\t")}
CHECKED_FIELDS={
    "O01":("orientation_id",),"O02":("orientation_id",),"O03":("orientation_id",),"O04":("orientation_id",),
    "A01":("reference_stage_id",),"A02":("reference_stage_id",),
    "A03":("reference_stage_id",),"A04":("reference_stage_id",),
    "X01":("result_stage_id",),"X02":("orientation_id",),
    "X03":("reference_stage_id","result_stage_id"),"X04":("reference_stage_id",),
}
SCHEMAS=deepcopy(SCHEMAS)
SCHEMAS["ask_engineer"]=object_schema({
    "fields":{"type":"array","items":{"enum":["orientation_id","reference_stage_id","result_stage_id"]},
              "uniqueItems":True,"minItems":1},
    "question":{"type":"string","minLength":5},
})


def new_episode(episode_id):
    state=new_state()
    missing=CHECKED_FIELDS.get(episode_id,())
    state.update(episode_id=episode_id, pending=list(missing), orientation_received="orientation_id" not in missing)
    return state


def local_dispatch(state,tool,a):
    if tool=="read_model":
        answer=dispatch(state,tool,a)
        if answer["status"]=="OK":
            answer["stage_roles"]={"initial":"INITIAL","temporary_support":"TEMP_SUPPORT",
                                   "primary_support":REFERENCE,"end_excavation":RESULT}
            answer["available_stage_ids"]=["INITIAL","TEMP_SUPPORT",REFERENCE,RESULT]
            answer["axis_convention_supported"]=ORIENTATION
        return answer

    if tool=="ask_engineer":
        pending=state["pending"]
        if any(field not in pending for field in a["fields"]):
            return result("NO_OUTSTANDING_FIELD",fields=a["fields"])
        answer={field:SPEC[field] for field in a["fields"]}
        state["pending"]=[field for field in pending if field not in answer]
        if "orientation_id" in answer:
            state["orientation_received"]=True
        return result("FIXTURE_REPLY",source="pre-recorded engineer reply",resolved=answer)

    if tool=="prepare_spec":
        pending=state["pending"]
        non_grounded=[key for key in pending if a[key]==SPEC[key]]
        if non_grounded:
            return result("EVIDENCE_REQUIRED",fields=non_grounded)
        if a["reference_stage_id"]=="TEMP_SUPPORT":
            return result("STAGE_ROLE_MISMATCH",proposed="TEMP_SUPPORT",required_role="primary_support")
        return dispatch(state,tool,a)
    return dispatch(state,tool,a)


def call(state,tool,args):
    failures=list(Draft202012Validator(SCHEMAS[tool]).iter_errors(args))
    answer=result("SCHEMA_ERROR",details=failures[0].message) if failures else local_dispatch(state,tool,args)
    state["calls"].append({"step":len(state["calls"])+1,"origin":"language_model_controller",
                           "tool":tool,"arguments":args,"result":answer})
    return answer


def main():
    parser=ArgumentParser()
    parser.add_argument("episode",choices=CASES)
    parser.add_argument("tool",choices=[*SCHEMAS,"prompt"])
    args=parser.parse_args()
    if args.tool=="prompt":
        print(CASES[args.episode]["request"])
        return
    states=ROOT/"episodes"
    states.mkdir(exist_ok=True)
    path=states/f"{args.episode}.json"
    state=json.loads(path.read_text()) if path.exists() else new_episode(args.episode)
    value=call(state,args.tool,json.load(sys.stdin))
    pending=path.with_suffix(".tmp")
    pending.write_text(json.dumps(state,indent=2,allow_nan=False))
    pending.replace(path)
    print(json.dumps(value,allow_nan=False))


if __name__=="__main__":
    main()
