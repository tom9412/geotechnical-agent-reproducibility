"""Stateful tool boundary for the controller demonstration in the chapter.

The synthetic adapter and the trusted fixture manifest are for this demonstration.
No Rocscience files are opened. Each CLI invocation runs one model-selected tool.
"""
from argparse import ArgumentParser
from hashlib import sha256
import json
from math import cos, radians, sin
from pathlib import Path
import sys

from jsonschema import Draft202012Validator
import numpy as np

from benchmark import response, sample


MODEL = "tunnel-fixture-v1"
REFERENCE = "SUPPORT_INSTALLED"
RESULT = "END_EXCAVATION"
ORIENTATION = "RS2_CCW_FROM_POSITIVE_X_DEG"
PLAN = "MC64_SEED_8241"
SPEC = dict(model_id=MODEL, sample_plan_id=PLAN, reference_stage_id=REFERENCE,
            result_stage_id=RESULT, orientation_id=ORIENTATION)
SEED = 8241
N = 64
RESPONSE_LIMITS = {"closure_mm": 30., "bolt_kN": 358.}
STAGES = ["INITIAL", REFERENCE, RESULT]
INJECTED = {"S017": "TRANSIENT_IO", "S042": "NONCONVERGED", "S052": "READBACK_MISMATCH"}


def digest(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return sha256(payload).hexdigest()[:12]


APPROVED = digest(SPEC)


def object_schema(fields):
    return {"type": "object", "additionalProperties": False,
            "properties": fields, "required": list(fields)}


string = {"type": "string"}
nullable = {"type": ["string", "null"]}
SCHEMAS = {
    "read_model": object_schema({"model_id": string}),
    "prepare_spec": object_schema({key: (string if key in ("model_id", "sample_plan_id") else nullable)
                                   for key in SPEC}),
    "ask_engineer": object_schema({"field": {"enum": ["orientation_id"]}, "question": {"type":"string","minLength":5}}),
    "run_pilot": object_schema({"spec_id": string}),
    "run_batch": object_schema({"spec_id": string}),
    "act_on_status": object_schema({"spec_id": string, "sample_id": string,
                                     "action": {"enum": ["retry_same_inputs", "flag_for_review"]}}),
    "report": object_schema({"spec_id": string}),
}


def result(status, **fields):
    return {"status": status, **fields}


def new_state():
    return {"specs": {}, "pilots": {}, "batches": {}, "orientation_received": False, "calls": []}


def stress(inheritance, theta):
    major, out, minor = 5.+20.*inheritance, 5.+9.*inheritance, 5.
    angle = radians(theta)
    c, s = cos(angle), sin(angle)
    return {"sigma_1": major, "sigma_z": out, "sigma_3": minor,
            "theta_deg": float(theta), "xx": major*c*c+minor*s*s,
            "yy": major*s*s+minor*c*c, "xy": (major-minor)*s*c}


def pilot_checks(inheritance_values=None):
    if inheritance_values is None:
        inheritance_values = (0., 1.)
    relaxed, regional = (stress(v, 0.) for v in inheritance_values)
    changed = stress(0., 37.)
    axes = ("xx", "yy", "xy", "sigma_z")
    pair = np.array([[0.,0.,0.],[0.,0.,37.]])
    rotated = stress(.325, 22.5)
    return {
        "relaxed_end_member": np.allclose([relaxed[k] for k in axes],[5.,5.,0.,5.]),
        "regional_end_member": np.allclose([regional[k] for k in axes],[25.,5.,0.,14.]),
        "positive_rotation": bool(abs(rotated["xy"]-2.29809704)<1e-7),
        "isotropic_angle_invariance": bool(np.allclose([relaxed[k] for k in axes],[changed[k] for k in axes])
                                          and np.allclose(*response(pair))),
        "response_anchor": np.allclose(response(np.array([[.325,0.,0.]])), [[29.5,350.]]),
    }


def create_rows():
    inputs = sample(np.random.default_rng(SEED).standard_normal((N,3)))
    return {f"S{i:03d}": {"input": [float(v) for v in vector],
                         "input_id": digest([float(v) for v in vector]), "attempts": [], "review": False}
            for i,vector in enumerate(inputs,1)}


def attempt(case_id, case):
    vector = case["input"]
    current = len(case["attempts"])+1
    branch = INJECTED.get(case_id) if current==1 else None
    observed = {"attempt": current,"sample_id": case_id,"input_id": case["input_id"],"result_stage": RESULT}
    if branch in ("TRANSIENT_IO","NONCONVERGED"):
        stage = RESULT if branch=="NONCONVERGED" else None
        observed |= {"status":branch,"failed_stage":stage}
    else:
        applied = stress(vector[0],vector[2])
        written = applied.copy()
        if branch=="READBACK_MISMATCH":
            written["theta_deg"] += 8.
        if not np.isclose(applied["theta_deg"],written["theta_deg"],atol=1e-8,rtol=0.):
            observed |= {"status":"READBACK_MISMATCH","field":"theta_deg",
                         "requested":applied["theta_deg"],"read_back":written["theta_deg"]}
        else:
            u,t = response(np.array([vector]))[0]
            observed |= {"status":"OK","closure_mm":float(u),"bolt_kN":float(t)}
    case["attempts"].append(observed)
    return observed


def batch_gate(state,spec_id):
    if spec_id not in state["specs"]:
        return result("UNKNOWN_SPEC")
    if spec_id != APPROVED:
        return result("APPROVAL_REQUIRED")
    return None


def dispatch(state,tool,a):
    if tool=="read_model":
        if a["model_id"]!=MODEL:
            return result("UNKNOWN_MODEL")
        return result("OK",model_id=MODEL,backend="synthetic",
                      available_stage_ids=STAGES,stage_roles={"reference":REFERENCE,"result":RESULT},
                      orientation_id=ORIENTATION if state["orientation_received"] else None)

    if tool=="prepare_spec":
        if a["model_id"]!=MODEL:
            return result("UNKNOWN_MODEL")
        if a["sample_plan_id"]!=PLAN:
            return result("UNKNOWN_PLAN")
        unresolved=[key for key in ("reference_stage_id","result_stage_id","orientation_id") if a[key] is None]
        if unresolved:
            return result("NEED_INPUT",outstanding=unresolved)
        bad=[a[key] for key in ("reference_stage_id","result_stage_id") if a[key] not in STAGES]
        if bad:
            return result("UNKNOWN_STAGE",proposed=bad,available_stage_ids=STAGES)
        if STAGES.index(a["result_stage_id"])<=STAGES.index(a["reference_stage_id"]):
            return result("STAGE_ORDER_INVALID")
        if a["orientation_id"]!=ORIENTATION:
            return result("UNSUPPORTED_ORIENTATION")
        if not state["orientation_received"]:
            return result("ORIENTATION_UNVERIFIED",field="orientation_id")
        spec_id=digest(a)
        state["specs"][spec_id]=a
        return result("APPROVED" if spec_id==APPROVED else "APPROVAL_REQUIRED",spec_id=spec_id,
                      sample_count=N,response_limits=RESPONSE_LIMITS)

    if tool=="ask_engineer":
        # Trusted response is a scripted fixture, external to the model proposal.
        state["orientation_received"]=True
        return result("FIXTURE_REPLY",source="scripted engineer fixture",orientation_id=ORIENTATION)

    gate=batch_gate(state,a["spec_id"])
    if gate:
        return gate
    spec_id=a["spec_id"]

    if tool=="run_pilot":
        checks=pilot_checks()
        state["pilots"][spec_id]=all(checks.values())
        return result("PASS" if all(checks.values()) else "PILOT_FAILED",checks=checks)

    if tool=="run_batch":
        if not state["pilots"].get(spec_id):
            return result("PILOT_REQUIRED")
        if spec_id in state["batches"]:
            return result("BATCH_EXISTS")
        cases=create_rows()
        state["batches"][spec_id]=cases
        attempts=[attempt(case_id,case) for case_id,case in cases.items()]
        exceptions=[item for item in attempts if item["status"]!="OK"]
        return result("BATCH_COMPLETE",initial_attempts=len(attempts),resolved=len(attempts)-len(exceptions),
                      exceptions=exceptions)

    cases=state["batches"].get(spec_id)
    if not cases:
        return result("NO_BATCH")

    if tool=="act_on_status":
        case=cases.get(a["sample_id"])
        if case is None:
            return result("UNKNOWN_SAMPLE")
        last=case["attempts"][-1]
        if last["status"]=="OK" or case["review"]:
            return result("ALREADY_HANDLED")
        if a["action"]=="retry_same_inputs":
            if last["status"]!="TRANSIENT_IO" or len(case["attempts"])!=1:
                return result("RETRY_BLOCKED",sample_id=a["sample_id"],reason=last["status"])
            return result("RETRIED",outcome=attempt(a["sample_id"],case))
        case["review"]=True
        return result("FLAGGED_FOR_REVIEW", sample_id=a["sample_id"], open_status=last["status"],
                      failed_stage=last.get("failed_stage"), attempt_count=len(case["attempts"]))

    classifications=[case["attempts"][-1] for case in cases.values()]
    known=[row for row in classifications if row["status"]=="OK"]
    pending=[case_id for case_id,case in cases.items()
             if case["attempts"][-1]["status"]!="OK" and not case["review"]]
    if pending:
        return result("ACTIONS_PENDING",sample_ids=pending)
    counts={}
    for key,limit in RESPONSE_LIMITS.items():
        k=sum(row[key]>limit for row in known)
        counts[key]={"exceedances":k,"lower":k/N,"upper":(k+N-len(known))/N}
    return result("REPORT_READY",planned=N, resolved=len(known),unresolved=N-len(known),
                  total_attempts=sum(len(case["attempts"]) for case in cases.values()), counts=counts)


def call(state,tool,args,origin="agent_session"):
    if tool not in SCHEMAS:
        output=result("UNKNOWN_TOOL")
    else:
        validation=list(Draft202012Validator(SCHEMAS[tool]).iter_errors(args))
        if validation:
            output=result("SCHEMA_ERROR",details=validation[0].message)
        else:
            output=dispatch(state,tool,args)
    state["calls"].append({"step":len(state["calls"])+1,"origin":origin,"tool":tool,
                           "arguments":args,"result":output})
    return output


def main():
    parser=ArgumentParser()
    parser.add_argument("state",type=Path)
    parser.add_argument("tool",choices=[*SCHEMAS,"schema"])
    opts=parser.parse_args()
    if opts.tool=="schema":
        print(json.dumps(SCHEMAS,indent=2))
        return
    state=json.loads(opts.state.read_text()) if opts.state.exists() else new_state()
    output=call(state,opts.tool,json.load(sys.stdin))
    pending=opts.state.with_suffix(".tmp")
    pending.write_text(json.dumps(state,indent=2,allow_nan=False))
    pending.replace(opts.state)
    print(json.dumps(output,indent=2,allow_nan=False))


if __name__=="__main__":
    main()
