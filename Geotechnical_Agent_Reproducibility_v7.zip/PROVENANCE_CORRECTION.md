# Provenance correction for the v6 record

The original controller session also had access to the study setup. Its Box 1 trace and original 16-request run are demonstrations. The 17 original traces in this archive are byte-identical to those in the v6 ZIP.

In original episodes X03 and X04, the controller submitted conflicting stage values on its first specification call. The dispatcher returned `STAGE_ORDER_INVALID` and `STAGE_ROLE_MISMATCH`, respectively. The controller then requested clarification and resubmitted. The records document the call sequence. They do not establish why the conflicting values were submitted.

The `deliberate_boundary_challenges` field added in v6 was a retrospective annotation without supporting pre-run documentation. That attribution was withdrawn. In this archive, `agent/run_metadata.json` records the correction without changing the original trace events.

Table 5 uses the separately recorded follow-up, with four fresh sessions and 16 requests. See `followup/protocol.md` for the session scope, `followup/observations/` for the traces, and `followup/score_followup.py` for replay and scoring. The original outcomes and the follow-up outcomes are reported separately.
