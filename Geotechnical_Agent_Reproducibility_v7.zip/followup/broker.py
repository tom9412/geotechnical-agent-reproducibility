"""Serve the existing dispatcher without exposing its implementation to a controller."""
import json
from pathlib import Path
import time
import sys

HERE = Path(__file__).resolve().parent
AGENT = HERE.parent / "agent"
sys.path.insert(0, str(AGENT))
from controller_eval import CASES, SCHEMAS, call, new_episode

GROUPS = {
    "birch": ["C01", "X02", "A03", "O04"],
    "cedar": ["A01", "O02", "C03", "X04"],
    "elm": ["X01", "C02", "O03", "A04"],
    "maple": ["O01", "A02", "X03", "C04"],
}
states = {group: {"index": 0, "active": None, "events": []} for group in GROUPS}
outputs = HERE / "observations"
public_files = ("study_instruction.txt", "tool_descriptions.txt", "tool_schema.json")

def process(group, data):
    if group not in GROUPS:
        return {"protocol_error": "Unknown session"}
    state = states[group]
    command = data.get("command")
    state["events"].append(data)
    (outputs / f"{group}_requests.json").write_text(json.dumps(state["events"], indent=2) + "\n")
    if command == "materials":
        return {name: (AGENT / name).read_text() for name in public_files}
    if command == "next":
        if state["active"] is not None:
            return {"protocol_error": "Finish the active request before advancing"}
        i = state["index"]
        if i == len(GROUPS[group]):
            return {"end": True}
        episode = GROUPS[group][i]
        state["active"] = new_episode(episode)
        return {"request": CASES[episode]["request"]}
    current = state["active"]
    if current is None:
        return {"protocol_error": "No active request"}
    if command == "tool" and data.get("tool") in SCHEMAS and "arguments" in data:
        if len(current["calls"]) >= 25:
            return {"protocol_error": "Tool call limit reached. Use finish."}
        answer = call(current, data["tool"], data["arguments"])
        (outputs / f'{current["episode_id"]}.json').write_text(json.dumps(current, indent=2) + "\n")
        return answer
    if command == "finish":
        (outputs / f'{current["episode_id"]}.json').write_text(json.dumps(current, indent=2) + "\n")
        state["active"] = None
        state["index"] += 1
        return {"request_recorded": True}
    return {"protocol_error": "Unsupported command or tool"}

if __name__ == "__main__":
    exchange = Path("/tmp/tunnel_request_study_v7")
    exchange.mkdir(mode=0o700, exist_ok=True)
    while True:
        for request in sorted(exchange.glob("*.request")):
            response = request.with_suffix(".response")
            message = json.loads(request.read_text())
            try:
                value = process(message["session"], message["data"])
            except (AttributeError, KeyError, TypeError, ValueError):
                value = {"protocol_error": "Invalid request"}
            stage = response.with_suffix(".pending")
            stage.write_text(json.dumps(value, allow_nan=False) + "\n")
            request.unlink()
            stage.replace(response)
        time.sleep(0.03)
