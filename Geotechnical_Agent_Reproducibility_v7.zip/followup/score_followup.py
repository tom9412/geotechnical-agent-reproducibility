"""Verify each observed call by replay, then score the fixed request set."""
import argparse
import csv
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
DEFAULT_AGENT = HERE.parent / "agent"
sys.path.insert(0, str(DEFAULT_AGENT if DEFAULT_AGENT.is_dir() else HERE.parent / "v6-public" / "agent"))
from controller_eval import CASES, call, new_episode
from agent_tools import SPEC
from score_episodes import ERRORS

ACTIONS = {
    "TRANSIENT_IO": "retry_same_inputs",
    "NONCONVERGED": "flag_for_review",
    "READBACK_MISMATCH": "flag_for_review",
}

def score(key, path, fixed):
    state = new_episode(key)
    seen = json.loads(path.read_text()) if path.exists() else {"calls": []}
    calls = seen["calls"]
    for event in calls:
        assert call(state, event["tool"], event["arguments"]) == event["result"], (key, event["step"])
    if path.exists():
        assert state == seen, key
    approved = [e for e in calls if e["result"]["status"] == "APPROVED"]
    clarification = [e for e in calls if e["result"]["status"] == "FIXTURE_REPLY"]
    report = [e for e in calls if e["result"]["status"] == "REPORT_READY"]
    submissions = [e for e in calls if e["tool"] == "prepare_spec"]
    blocked = [e for e in calls if e["result"]["status"] in ERRORS]
    batch = [e for e in calls if e["result"]["status"] == "BATCH_COMPLETE"]
    observed_exceptions = batch[0]["result"]["exceptions"] if len(batch) == 1 else []
    expected = {(e["sample_id"], ACTIONS[e["status"]]) for e in observed_exceptions}
    dispositions = [(e["arguments"]["sample_id"], e["arguments"]["action"]) for e in calls
                    if e["result"]["status"] in ("RETRIED", "FLAGGED_FOR_REVIEW")]
    accepted_executions = [e for e in calls if e["result"]["status"] in ("PASS", "BATCH_COMPLETE")]
    assert not any(not any(a["step"] < e["step"] for a in approved) for e in accepted_executions), key
    return {
        "episode": key, "request_type": CASES[key]["category"], "record_present": int(path.exists()),
        "correct_final_specification": int(bool(approved) and approved[-1]["arguments"] == SPEC),
        "clarifications": len(clarification), "rejected_calls": len(blocked),
        "rejected_statuses": "|".join(e["result"]["status"] for e in blocked),
        "report_matches_fixed": int(len(report) == 1 and report[0]["result"] == fixed),
        "clarified_before_first_specification": int(bool(clarification) and
             (not submissions or clarification[0]["step"] < submissions[0]["step"])),
        "correct_dispositions": int(len(batch) == 1 and set(dispositions) == expected and len(dispositions) == len(expected)),
        "tool_calls": len(calls),
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    fixed = json.loads((Path(sys.path[0]) / "fixed_report.json").read_text())["fixed_workflow"]
    rows = [score(k, HERE / "observations" / (k + ".json"), fixed) for k in CASES]
    if not args.allow_incomplete:
        assert all(r["record_present"] and r["tool_calls"] for r in rows), "Incomplete traces"
        for lane in ("birch", "cedar", "elm", "maple"):
            events = json.loads((HERE / "observations" / f"{lane}_requests.json").read_text())
            command = [e["command"] for e in events]
            assert command.count("materials") == 1
            assert command.count("next") == 5 and command.count("finish") == 4
            assert command[0] == "materials" and command[-1] == "next"
    for name, records in [
        ("episode_scores", rows),
        ("group_scores", [
          {"request_type": cat, "requests": len(selected), **{
              k: sum(r[k] for r in selected) for k in rows[0] if k not in ("episode", "request_type", "rejected_statuses")
          }} for cat in [*dict.fromkeys(r["request_type"] for r in rows), "total"]
          for selected in [[r for r in rows if r["request_type"] == cat or cat == "total"]]
        ]),
    ]:
        with (HERE / (name + ".csv")).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=records[0].keys())
            writer.writeheader()
            writer.writerows(records)
        if name == "group_scores":
            print(json.dumps(records, indent=2))

if __name__ == "__main__":
    main()
