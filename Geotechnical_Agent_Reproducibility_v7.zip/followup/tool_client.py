import json
from pathlib import Path
import sys
import time
import uuid

base = Path("/tmp/tunnel_request_study_v7") / uuid.uuid4().hex
request, response = base.with_suffix(".request"), base.with_suffix(".response")
temporary = base.with_suffix(".staged")
request_data = {"session": sys.argv[1], "data": json.loads(sys.argv[2])}
temporary.write_text(json.dumps(request_data) + "\n")
temporary.replace(request)
deadline = time.monotonic() + 10
while not response.exists():
    if time.monotonic() > deadline:
        raise TimeoutError("No result from the tool interface")
    time.sleep(0.04)
print(response.read_text(), end="")
response.unlink()
