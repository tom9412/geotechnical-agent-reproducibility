Reproduction package for An AI Agent for Probabilistic Geotechnical Analysis
v6, Sections 5.3 and 6.1

Run date: 16 November 2026 (Australia/Sydney).
The observations used an interactive language-model controller and a
command adapter. Product and interface labels are generalised. Run settings and available version metadata are
in run_metadata.json. The study instruction is given in study_instruction.txt.
The application-level tool descriptions and schemas accompany it. Provider
system instructions and exact model inference settings are outside the record.

The extra coverage study used sixteen fresh dispatcher states within one model
conversation. The controller chose the tool calls using the prompts and the
returned observations. Equivalent next actions were grouped across requests and
executed with their individual dispatcher states. The coverage set shared one
conversation. In X03 and X04 the first specifications were deliberate conflict
submissions to exercise the dispatcher. The tool traces retain the original
arguments and results.
The clarification answers are pre-recorded, and the response backend is
synthetic. Each episode used the same deterministic 64-case sample plan.

Files
  study_instruction.txt, tool_descriptions.txt, tool_schema.json, prompts.tsv
    Complete study-specific instruction, tool interface and request set.
  run_metadata.json, episodes/*.json
    Run provenance and recorded calls, outputs, and sample/attempt records.
  controller_eval.py, agent_tools.py, benchmark.py
    Dispatcher, original protocol and synthetic response generator.
  score_episodes.py, episode_scores.csv, group_scores.csv, fixed_report.json
    Episode replay, scoring, fixed comparator and fully observed reference.
  reference_request.txt, reference_trace.json, reference_tool_schema.json
    Original Box 1 request, tool trace and corresponding protocol.
  evaluate_reference.py, reference_evaluation.json, guard_results.csv
    Replay, original reference assessment and fourteen scripted probes.
  requirements.txt
    Dependency versions used by the Python evaluation.

Use Python 3.12:
    python -m pip install -r requirements.txt
    python evaluate_reference.py
    python score_episodes.py

The scripts replay the saved tool calls into clean states and reproduce the
numeric reports and evaluation tables without invoking a model. To investigate
different model runs, present the supplied instruction and request to a
controller with access to the tool descriptions and command interface, and use
fresh copies of the episode output directory. Keep the pre-recorded response
mechanism on the dispatcher side. The demo's preloaded approval fingerprint
stands in for an independently approved engineering specification.
