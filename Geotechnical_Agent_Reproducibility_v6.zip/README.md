# Geotechnical Agent Reproducibility

These materials accompany *An AI Agent for Probabilistic Geotechnical Analysis with an Application to Tunnel Support* by Xuanchi Liu.

Download [the reproducibility archive](Geotechnical_Agent_Reproducibility_v6.zip) and extract it locally.

- **Agent and evaluation** (`agent/`): study instruction, tool contracts, 16 request texts and traces, reference episode, dispatcher probes, fixed-workflow comparator, and replay and scoring scripts.
- **Synthetic benchmark** (`benchmark/`): data tables, code, and vector figures for Experiments 1–3.

Each folder includes its own dependency versions and reproduction commands. The recorded agent requests shared a single conversation, and two of the invalid first specifications were deliberate challenges for the dispatcher. The replay scripts recreate the recorded dispatcher responses without querying a language model. The response backend and the numerical experiments are synthetic.
